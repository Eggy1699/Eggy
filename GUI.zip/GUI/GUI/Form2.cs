﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        public void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "Admin" && textBox2.Text == "012345")
            {
                MessageBox.Show("Welcome!!!", "Result", MessageBoxButtons.OK, MessageBoxIcon.Information);               
                Form1 f1 = new Form1();                
                f1.Show();
                Hide();
                                  
                               
            }
            else
            {
                MessageBox.Show("Invalid Username or Password", "Result", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        
        

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
        }
        
    }
}
